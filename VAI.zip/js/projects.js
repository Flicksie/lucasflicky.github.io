
		var projecthood = [

				[
				name		=	"	",
				category	=	"	",
				displayPic	=	"	",
				icon		=	"	",
				describ		=	"	",
				],
				
				[
				name		=	"	",
				category	=	"	",
				displayPic	=	"	",
				icon		=	"	",
				describ		=	"	",
				],
				
				

		]
		
		
		var veritassia = printProj(projecthood[1],projecthood[2],projecthood[3],projecthood[4],projecthood[5]);